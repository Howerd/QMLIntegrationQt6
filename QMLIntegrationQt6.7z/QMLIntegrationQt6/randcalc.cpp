// randcalc.cpp

#include <randcalc.h>

RandCalc::RandCalc(QObject *parent)
	: QObject{parent}
{
}

void RandCalc::calculate(QVariant data)
{
	bool isNum;
	int input = data.toInt(&isNum);
	int output = 0;

	if( isNum ) 
	{
		int randNum = QRandomGenerator::global()->bounded(100);
		output = input * randNum;
	}
	else
	{
		qWarning() << "Not a number";
	}

	emit calculatedNumber(QVariant(output));
}
