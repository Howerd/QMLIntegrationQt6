// randcalc.h

#ifndef RANDCAL_H
#define RANDCAL_H

#include <QObject>
#include <QVariant>
#include <QtQml>
#include <QRandomGenerator>

class RandCalc : public QObject
{
    Q_OBJECT
	QML_ELEMENT
public:
    explicit RandCalc(QObject *parent = nullptr);

signals:
	void calculatedNumber(QVariant data);

public slots:
	void calculate(QVariant data);

private:

};

#endif // RANDCAL_H
